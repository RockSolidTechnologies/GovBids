//
//  RSTAppDelegate.h
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <UIKit/UIKit.h>

//@interface RSTAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,UINavigationControllerDelegate>
@interface RSTAppDelegate : NSObject <UIApplicationDelegate>

@property (strong, nonatomic) IBOutlet UIWindow *window;
@property (strong, nonatomic) UITabBarController *tabBarController;
@property (strong, nonatomic) UINavigationController *navigationController;

@end
