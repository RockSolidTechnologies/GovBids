//
//  RSTSecondViewController.m
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import "BidDetailViewController.h"

@interface BidDetailViewController ()

@end

@implementation BidDetailViewController
@synthesize url;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Detalles", @"Detalles");
        self.tabBarItem.image = [UIImage imageNamed:@"second"];
    }
    return self;
}


- (id)initWithURL:(NSString *)url{
    self = [super init];
    if (self) {
        self.url = url;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSURL *myURL= [NSURL URLWithString:[self.url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLRequest *request=[NSURLRequest requestWithURL:myURL];
    self.webView.scalesPageToFit= YES;
    [self.webView loadRequest:request];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
