//
//  FiltersViewController.m
//  GovBids
//
//  Created by RSTDeveloper01 on 6/2/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import "FiltersViewController.h"
#import "KeywordsViewController.h"
#import "AgencyViewController.h"
#import "CategoryViewController.h"
#import "LocationViewController.h"
#import "Data.h"
#import "RSTAppDelegate.h"

@interface FiltersViewController ()

@end

@implementation FiltersViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Filtros", @"Filtros");
        self.tabBarItem.image = [UIImage imageNamed:@"equalizer"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];;
    NSLog(@"View Did Load:%@",[[Data sharedData]filters]);
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    NSLog(@"View Did Load:%@",[[Data sharedData]filters]);
    [self.filtersView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0) {
        return [[[[Data sharedData] filters] objectForKey:@"Filters"] count];
    }
    else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *docPath = [documentsDirectory stringByAppendingPathComponent:@"Filters.plist"];
    
    
    NSLog(@"Doc Path: %@",docPath);
    

    NSMutableDictionary *filters = [[[[Data sharedData] filters] objectForKey:@"Filters"] objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"] autorelease];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [filters objectForKey:@"Name"];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    switch (indexPath.row){
        case 0:
            [self.navigationController pushViewController:[[KeywordsViewController alloc]initController:@"Keywords"] animated:YES];
            break;
        case 1:
            [self.navigationController pushViewController:[[AgencyViewController alloc]initController:@"Agencies"] animated:YES];
            break;
        case 2:
            [self.navigationController pushViewController:[[CategoryViewController alloc]initController:@"Categories"] animated:YES];
            break;
        case 3:
            [self.navigationController pushViewController:[[LocationViewController alloc]initController:@"Locations"] animated:YES];
            break;
        default:
            break;
    }

}

@end
