//
//  CategoryViewController.h
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AvailBids.h"

@interface CategoryViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,AvailBidsSoapResponseDelegate,NSXMLParserDelegate>
{
}
@property (strong, nonatomic) IBOutlet UITextField *selectedCategory;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerView;
@end
