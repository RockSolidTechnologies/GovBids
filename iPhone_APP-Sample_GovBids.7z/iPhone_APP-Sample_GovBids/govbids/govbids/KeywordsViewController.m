//
//  KeywordsViewController.m
//  GovBids
//
//  Created by RSTDeveloper01 on 6/2/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import "KeywordsViewController.h"
#import "Data.h"

@interface KeywordsViewController ()

@end

@implementation KeywordsViewController

@synthesize keywordsTextField;
@synthesize agencies;
@synthesize locations;
@synthesize categories;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Palabras claves", @"Palabras claves");
    }
    return self;
}

-(id) initController:(NSString *)name{
    self = [super init];
    
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view from its nib.
}

-(void) didMoveToParentViewController:(UIViewController *)parent{
    if (![parent isEqual:self.parentViewController]) {
        NSLog(@"Back pressed");
    }
    
    [[Data sharedData] setKeywords:self.keywordsTextField.text];
   
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *docPath = [documentsDirectory stringByAppendingPathComponent:@"Filters.plist"];
    
    
    NSLog(@"Doc Path: %@",docPath);
    
    NSMutableDictionary* updateVal=[[NSMutableDictionary alloc] initWithContentsOfFile:docPath];

    
    NSString *updateValString= [updateVal valueForKey:@"Filters"];
    
    NSLog(@"Update val string:%@",updateValString);
    
    
    
    NSMutableDictionary *filtersDict = [[NSMutableDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Filters" ofType:@"plist"]];
    NSMutableArray *filters = [filtersDict objectForKey:@"Filters"];
    NSMutableDictionary *keywords= [filters objectAtIndex:0];
    NSLog(@"Keywords: %@",keywords);
    
    [keywords setValue:self.keywordsTextField.text forKey:@"Values"];
    NSLog(@"Keywords new value:%@",self.keywordsTextField.text);
    
    [filters setObject:keywords atIndexedSubscript:0];
    [filtersDict setObject:filters forKey:@"Filters"];
    
    
    [updateVal setObject:filtersDict forKey:@"Filters"];
    [updateVal writeToFile:docPath atomically:NO];
    [updateVal release];
    
    NSMutableDictionary* updateVal2=[[NSMutableDictionary alloc] initWithContentsOfFile:docPath];

    NSLog(@"%@",updateVal2);
    
}

-(void) dealloc
{
    [keywordsTextField release];
    [_agencyPicker release];
    [_agencyTextField release];
    [_categoryTextField release];
    [_locationTextField release];
    [super dealloc];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark -
#pragma mark PickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    return [agencies count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    return [agencies objectAtIndex:row];
}

#pragma mark -
#pragma mark PickerView Delegate
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{   
    self.agencyTextField.text= [agencies objectAtIndex:row];
}

-(IBAction)textFieldReturn:(id)sender
{
    [sender resignFirstResponder];
}

@end
