#import <Foundation/Foundation.h>
#import "USAdditions.h"
#import <libxml/tree.h>
#import "USGlobals.h"
@class AvailBids_GetBids;
@class AvailBids_GetBidsResponse;
@class AvailBids_GetCategories;
@class AvailBids_GetCategoriesResponse;
@class AvailBids_GetAgencies;
@class AvailBids_GetAgenciesResponse;
@class AvailBids_GetLocations;
@class AvailBids_GetLocationsResponse;
@interface AvailBids_GetBids : NSObject {
	
/* elements */
	NSString * agency;
	NSString * category;
	NSString * location;
	NSString * title;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetBids *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * agency;
@property (retain) NSString * category;
@property (retain) NSString * location;
@property (retain) NSString * title;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetBidsResponse : NSObject {
	
/* elements */
	NSString * GetBidsResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetBidsResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * GetBidsResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetCategories : NSObject {
	
/* elements */
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetCategories *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetCategoriesResponse : NSObject {
	
/* elements */
	NSString * GetCategoriesResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetCategoriesResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * GetCategoriesResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetAgencies : NSObject {
	
/* elements */
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetAgencies *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetAgenciesResponse : NSObject {
	
/* elements */
	NSString * GetAgenciesResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetAgenciesResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * GetAgenciesResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetLocations : NSObject {
	
/* elements */
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetLocations *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
/* attributes */
- (NSDictionary *)attributes;
@end
@interface AvailBids_GetLocationsResponse : NSObject {
	
/* elements */
	NSString * GetLocationsResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (AvailBids_GetLocationsResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * GetLocationsResult;
/* attributes */
- (NSDictionary *)attributes;
@end
/* Cookies handling provided by http://en.wikibooks.org/wiki/Programming:WebObjects/Web_Services/Web_Service_Provider */
#import <libxml/parser.h>
#import "xsd.h"
#import "AvailBids.h"
@class AvailBidsSoap;
@class AvailBidsSoap12;
@interface AvailBids : NSObject {
	
}
+ (AvailBidsSoap *)AvailBidsSoap;
+ (AvailBidsSoap12 *)AvailBidsSoap12;
@end
@class AvailBidsSoapResponse;
@class AvailBidsSoapOperation;
@protocol AvailBidsSoapResponseDelegate <NSObject>
- (void) operation:(AvailBidsSoapOperation *)operation completedWithResponse:(AvailBidsSoapResponse *)response;
@end
@interface AvailBidsSoap : NSObject <AvailBidsSoapResponseDelegate> {
	NSURL *address;
	NSTimeInterval defaultTimeout;
	NSMutableArray *cookies;
	BOOL logXMLInOut;
	BOOL synchronousOperationComplete;
	NSString *authUsername;
	NSString *authPassword;
}
@property (copy) NSURL *address;
@property (assign) BOOL logXMLInOut;
@property (assign) NSTimeInterval defaultTimeout;
@property (nonatomic, retain) NSMutableArray *cookies;
@property (nonatomic, retain) NSString *authUsername;
@property (nonatomic, retain) NSString *authPassword;
- (id)initWithAddress:(NSString *)anAddress;
- (void)sendHTTPCallUsingBody:(NSString *)body soapAction:(NSString *)soapAction forOperation:(AvailBidsSoapOperation *)operation;
- (void)addCookie:(NSHTTPCookie *)toAdd;
- (AvailBidsSoapResponse *)GetBidsUsingParameters:(AvailBids_GetBids *)aParameters ;
- (void)GetBidsAsyncUsingParameters:(AvailBids_GetBids *)aParameters  delegate:(id<AvailBidsSoapResponseDelegate>)responseDelegate;
- (AvailBidsSoapResponse *)GetCategoriesUsingParameters:(AvailBids_GetCategories *)aParameters ;
- (void)GetCategoriesAsyncUsingParameters:(AvailBids_GetCategories *)aParameters  delegate:(id<AvailBidsSoapResponseDelegate>)responseDelegate;
- (AvailBidsSoapResponse *)GetAgenciesUsingParameters:(AvailBids_GetAgencies *)aParameters ;
- (void)GetAgenciesAsyncUsingParameters:(AvailBids_GetAgencies *)aParameters  delegate:(id<AvailBidsSoapResponseDelegate>)responseDelegate;
- (AvailBidsSoapResponse *)GetLocationsUsingParameters:(AvailBids_GetLocations *)aParameters ;
- (void)GetLocationsAsyncUsingParameters:(AvailBids_GetLocations *)aParameters  delegate:(id<AvailBidsSoapResponseDelegate>)responseDelegate;
@end
@interface AvailBidsSoapOperation : NSOperation {
	AvailBidsSoap *binding;
	AvailBidsSoapResponse *response;
	id<AvailBidsSoapResponseDelegate> delegate;
	NSMutableData *responseData;
	NSURLConnection *urlConnection;
}
@property (retain) AvailBidsSoap *binding;
@property (readonly) AvailBidsSoapResponse *response;
@property (nonatomic, assign) id<AvailBidsSoapResponseDelegate> delegate;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSURLConnection *urlConnection;
- (id)initWithBinding:(AvailBidsSoap *)aBinding delegate:(id<AvailBidsSoapResponseDelegate>)aDelegate;
@end
@interface AvailBidsSoap_GetBids : AvailBidsSoapOperation {
	AvailBids_GetBids * parameters;
}
@property (retain) AvailBids_GetBids * parameters;
- (id)initWithBinding:(AvailBidsSoap *)aBinding delegate:(id<AvailBidsSoapResponseDelegate>)aDelegate
	parameters:(AvailBids_GetBids *)aParameters
;
@end
@interface AvailBidsSoap_GetCategories : AvailBidsSoapOperation {
	AvailBids_GetCategories * parameters;
}
@property (retain) AvailBids_GetCategories * parameters;
- (id)initWithBinding:(AvailBidsSoap *)aBinding delegate:(id<AvailBidsSoapResponseDelegate>)aDelegate
	parameters:(AvailBids_GetCategories *)aParameters
;
@end
@interface AvailBidsSoap_GetAgencies : AvailBidsSoapOperation {
	AvailBids_GetAgencies * parameters;
}
@property (retain) AvailBids_GetAgencies * parameters;
- (id)initWithBinding:(AvailBidsSoap *)aBinding delegate:(id<AvailBidsSoapResponseDelegate>)aDelegate
	parameters:(AvailBids_GetAgencies *)aParameters
;
@end
@interface AvailBidsSoap_GetLocations : AvailBidsSoapOperation {
	AvailBids_GetLocations * parameters;
}
@property (retain) AvailBids_GetLocations * parameters;
- (id)initWithBinding:(AvailBidsSoap *)aBinding delegate:(id<AvailBidsSoapResponseDelegate>)aDelegate
	parameters:(AvailBids_GetLocations *)aParameters
;
@end
@interface AvailBidsSoap_envelope : NSObject {
}
+ (AvailBidsSoap_envelope *)sharedInstance;
- (NSString *)serializedFormUsingHeaderElements:(NSDictionary *)headerElements bodyElements:(NSDictionary *)bodyElements;
@end
@interface AvailBidsSoapResponse : NSObject {
	NSArray *headers;
	NSArray *bodyParts;
	NSError *error;
}
@property (retain) NSArray *headers;
@property (retain) NSArray *bodyParts;
@property (retain) NSError *error;
@end
@class AvailBidsSoap12Response;
@class AvailBidsSoap12Operation;
@protocol AvailBidsSoap12ResponseDelegate <NSObject>
- (void) operation:(AvailBidsSoap12Operation *)operation completedWithResponse:(AvailBidsSoap12Response *)response;
@end
@interface AvailBidsSoap12 : NSObject <AvailBidsSoap12ResponseDelegate> {
	NSURL *address;
	NSTimeInterval defaultTimeout;
	NSMutableArray *cookies;
	BOOL logXMLInOut;
	BOOL synchronousOperationComplete;
	NSString *authUsername;
	NSString *authPassword;
}
@property (copy) NSURL *address;
@property (assign) BOOL logXMLInOut;
@property (assign) NSTimeInterval defaultTimeout;
@property (nonatomic, retain) NSMutableArray *cookies;
@property (nonatomic, retain) NSString *authUsername;
@property (nonatomic, retain) NSString *authPassword;
- (id)initWithAddress:(NSString *)anAddress;
- (void)sendHTTPCallUsingBody:(NSString *)body soapAction:(NSString *)soapAction forOperation:(AvailBidsSoap12Operation *)operation;
- (void)addCookie:(NSHTTPCookie *)toAdd;
- (AvailBidsSoap12Response *)GetBidsUsingParameters:(AvailBids_GetBids *)aParameters ;
- (void)GetBidsAsyncUsingParameters:(AvailBids_GetBids *)aParameters  delegate:(id<AvailBidsSoap12ResponseDelegate>)responseDelegate;
- (AvailBidsSoap12Response *)GetCategoriesUsingParameters:(AvailBids_GetCategories *)aParameters ;
- (void)GetCategoriesAsyncUsingParameters:(AvailBids_GetCategories *)aParameters  delegate:(id<AvailBidsSoap12ResponseDelegate>)responseDelegate;
- (AvailBidsSoap12Response *)GetAgenciesUsingParameters:(AvailBids_GetAgencies *)aParameters ;
- (void)GetAgenciesAsyncUsingParameters:(AvailBids_GetAgencies *)aParameters  delegate:(id<AvailBidsSoap12ResponseDelegate>)responseDelegate;
- (AvailBidsSoap12Response *)GetLocationsUsingParameters:(AvailBids_GetLocations *)aParameters ;
- (void)GetLocationsAsyncUsingParameters:(AvailBids_GetLocations *)aParameters  delegate:(id<AvailBidsSoap12ResponseDelegate>)responseDelegate;
@end
@interface AvailBidsSoap12Operation : NSOperation {
	AvailBidsSoap12 *binding;
	AvailBidsSoap12Response *response;
	id<AvailBidsSoap12ResponseDelegate> delegate;
	NSMutableData *responseData;
	NSURLConnection *urlConnection;
}
@property (retain) AvailBidsSoap12 *binding;
@property (readonly) AvailBidsSoap12Response *response;
@property (nonatomic, assign) id<AvailBidsSoap12ResponseDelegate> delegate;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSURLConnection *urlConnection;
- (id)initWithBinding:(AvailBidsSoap12 *)aBinding delegate:(id<AvailBidsSoap12ResponseDelegate>)aDelegate;
@end
@interface AvailBidsSoap12_GetBids : AvailBidsSoap12Operation {
	AvailBids_GetBids * parameters;
}
@property (retain) AvailBids_GetBids * parameters;
- (id)initWithBinding:(AvailBidsSoap12 *)aBinding delegate:(id<AvailBidsSoap12ResponseDelegate>)aDelegate
	parameters:(AvailBids_GetBids *)aParameters
;
@end
@interface AvailBidsSoap12_GetCategories : AvailBidsSoap12Operation {
	AvailBids_GetCategories * parameters;
}
@property (retain) AvailBids_GetCategories * parameters;
- (id)initWithBinding:(AvailBidsSoap12 *)aBinding delegate:(id<AvailBidsSoap12ResponseDelegate>)aDelegate
	parameters:(AvailBids_GetCategories *)aParameters
;
@end
@interface AvailBidsSoap12_GetAgencies : AvailBidsSoap12Operation {
	AvailBids_GetAgencies * parameters;
}
@property (retain) AvailBids_GetAgencies * parameters;
- (id)initWithBinding:(AvailBidsSoap12 *)aBinding delegate:(id<AvailBidsSoap12ResponseDelegate>)aDelegate
	parameters:(AvailBids_GetAgencies *)aParameters
;
@end
@interface AvailBidsSoap12_GetLocations : AvailBidsSoap12Operation {
	AvailBids_GetLocations * parameters;
}
@property (retain) AvailBids_GetLocations * parameters;
- (id)initWithBinding:(AvailBidsSoap12 *)aBinding delegate:(id<AvailBidsSoap12ResponseDelegate>)aDelegate
	parameters:(AvailBids_GetLocations *)aParameters
;
@end
@interface AvailBidsSoap12_envelope : NSObject {
}
+ (AvailBidsSoap12_envelope *)sharedInstance;
- (NSString *)serializedFormUsingHeaderElements:(NSDictionary *)headerElements bodyElements:(NSDictionary *)bodyElements;
@end
@interface AvailBidsSoap12Response : NSObject {
	NSArray *headers;
	NSArray *bodyParts;
	NSError *error;
}
@property (retain) NSArray *headers;
@property (retain) NSArray *bodyParts;
@property (retain) NSError *error;
@end
