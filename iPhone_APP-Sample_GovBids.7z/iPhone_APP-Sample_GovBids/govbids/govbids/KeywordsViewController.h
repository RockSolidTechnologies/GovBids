//
//  KeywordsViewController.h
//  GovBids
//
//  Created by RSTDeveloper01 on 6/2/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface KeywordsViewController : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate>
{
 
}
@property (nonatomic,retain) IBOutlet UITextField *keywordsTextField;
@property (retain, nonatomic) IBOutlet UIPickerView *agencyPicker;
@property (retain, nonatomic) IBOutlet UIPickerView *categoryPicker;
@property (retain, nonatomic) IBOutlet UIPickerView *locationPicker;
@property (retain, nonatomic) IBOutlet UITextField *agencyTextField;
@property (retain, nonatomic) IBOutlet UITextField *categoryTextField;
@property (retain, nonatomic) IBOutlet UITextField *locationTextField;
@property (strong, nonatomic) NSArray *categories;
@property (strong, nonatomic) NSArray *agencies;
@property (strong, nonatomic) NSArray *locations;


-(id) initController:(NSString *)name;
-(IBAction)textFieldReturn:(id)sender;

@end



