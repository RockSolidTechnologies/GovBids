//
//  Data.h
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AvailBids.h"

@interface Agencies : NSObject<AvailBidsSoapResponseDelegate,NSXMLParserDelegate>
{
@public
    NSMutableArray *agencies;
}

@property (nonatomic,retain) NSMutableArray *agencies;

+ (id) sharedData;
-(void) load;
-(void) save;
-(void) loadAgencies;

@end
