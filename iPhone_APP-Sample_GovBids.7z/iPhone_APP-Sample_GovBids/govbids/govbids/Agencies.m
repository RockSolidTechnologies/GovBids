//
//  Agencies.h
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AvailBids.h"
#import "Agencies.h"

@interface Agencies() {
    NSXMLParser *parser;
    NSString *agency;
    NSMutableString *agencyName;
    NSString *element;
}

@end



@implementation Agencies

static id _sharedData = nil;
@synthesize agencies;


+ (void)initialize
{
    if (self == [Agencies class]) {
        _sharedData = [[self alloc] init];
    }
}

+ (id)sharedData
{
    return _sharedData;
}

- (id) init
{
    self = [super init];
    if (self) {
        agencies=[[NSMutableArray alloc]init];
    }
    return self;
}


#pragma mark - Loading functions
/**
 * Loads all the stored data
 */
- (void) load
{
}

-(void) save{
    
}

-(void) loadAgencies{
    AvailBidsSoap *availBids= [[AvailBids AvailBidsSoap]retain];
    availBids.logXMLInOut = YES;
    
    AvailBids_GetAgencies *getAgenciesRequest = [[AvailBids_GetAgencies new]autorelease];
    [availBids GetAgenciesAsyncUsingParameters:getAgenciesRequest delegate:self];
}

-(void) operation:(AvailBidsSoapResponse *)operation completedWithResponse:(AvailBidsSoapResponse *)response{
    
    NSArray *responseHeaders = response.headers;
    NSArray *responseBodyParts= response.bodyParts;
    
    for(id header in responseHeaders){
        
    }
    for(id bodyPart in responseBodyParts){
        /****
         * SOAP Fault Error
         ****/
        if ([bodyPart isKindOfClass:[SOAPFault class]]) {
            // You can get the error like this:
            //tV.text = ((SOAPFault *)bodyPart).simpleFaultString;
            continue;
        }
        
        if([bodyPart isKindOfClass:[AvailBids_GetAgenciesResponse class]]) {
            AvailBids_GetAgenciesResponse *body = (AvailBids_GetAgenciesResponse*) bodyPart;
            // Now you can extract the color from the response
            
            NSMutableString *s= [[NSMutableString alloc]initWithString:body.GetAgenciesResult];
            NSData *data=[s dataUsingEncoding:NSUTF16StringEncoding];
            
            parser= [[NSXMLParser alloc] initWithData:data];
            
            [parser setDelegate:self];
            [parser setShouldResolveExternalEntities:NO];
            [parser parse];
            break;
        }
        
    }
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    element = elementName;
    
    if ([element isEqualToString:@"Item"]) {
        agencyName   = [[NSMutableString alloc] init];
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([element isEqualToString:@"Item"]) {
        [agencyName appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"Item"]) {
        [agencies addObject:agencyName];
    }
}

@end

