//
//  LocationViewController.m
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import "LocationViewController.h"
@interface LocationViewController ()
{
    NSXMLParser *parser;
    NSString *location;
    NSMutableArray *locations;
    NSMutableString *locationName;
    NSString *element;
}
@end



@implementation LocationViewController
@synthesize selectedLocation;
@synthesize pickerView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
        self.title = NSLocalizedString(@"Localización", @"Localización");
        
    }
    return self;
}

-(id) initController:(NSString *)name{
    self = [super init];
    
    
    return self;
}

-(void) dealloc{
    [selectedLocation release];
    [super dealloc];
}

- (void)viewDidLoad
{
    
    
    
    [super viewDidLoad];
    //agencies= [[NSMutableArray alloc]initWithObjects:@"--Escoger Categoría--",@"Administración de Servicios de Salud Mental y Contra la Adicción (Dpto. Salud)",@"Administración para el Desarrollo de Empresas Agropecuarias (Dpto. Agricultura",@"Autoridad de Acueductos y Alcantarillados (AAA)",@"Autoridad para el Financiamiento de la Infraestructura de Puerto Rico (AFI)",@"Corporación del Fondo del Seguro del Estado (CFSE)",@"Corporación del Proyecto ENLACE del Caño Martín Peña",@"Departamento de Educación (DE)",@"Departamento de Justicia (DJ)",@"Departamento de Recreación y Deportes (DRD)",@"Departamento de Recursos Naturales y Ambientales (DRNA)",@"Departamento de Salud (DS)",@"Departamento de Transportación y Obras Públicas (DTOP)",@"Junta de Gobierno del Servicio 9-1-1",@"Policía de Puerto Rico",@"Universidad de Puerto Rico", nil];
    locations= [[NSMutableArray alloc]initWithObjects:@"--Escoger Localización--",@"Todo Puerto Rico",@"Aguas Buenas",@"Aguada",      @"Añasco",@"Area Metro",@"Arecibo",@"Barranquitas",@"Bayamón",      @"Carolina",@"Cayey",@"Fajardo",@"Gobierno de Puerto Rico",      @"Guaynabo",@"Gurabo",@"Hatillo",@"Luquillo",@"Orocovis",@"Ponce",@"Region Este",@"Region Norte",@"Region Oeste",@"Region Sur",      @"Rio Grande",@"Sabana Grande",@"Salinas",@"San Juan",@"Todo Puerto Rico",@"UPR en Aguadilla",@"UPR Recinto de Mayagüez",@"UPR Recinto de Río Piedras",@"Utuado",@"Varios",@"Vega Alta",nil];
    //[self loadLocations];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) loadLocations{
    AvailBidsSoap *availBids= [[AvailBids AvailBidsSoap]retain];
    availBids.logXMLInOut = YES;
    
    AvailBids_GetLocations *getLocationsRequest = [[AvailBids_GetLocations new]autorelease];
    [availBids GetLocationsAsyncUsingParameters:getLocationsRequest delegate:self];
}

-(void) operation:(AvailBidsSoapResponse *)operation completedWithResponse:(AvailBidsSoapResponse *)response{
    
    NSArray *responseHeaders = response.headers;
    NSArray *responseBodyParts= response.bodyParts;
    
    for(id header in responseHeaders){
        
    }
    for(id bodyPart in responseBodyParts){
        /****
         * SOAP Fault Error
         ****/
        if ([bodyPart isKindOfClass:[SOAPFault class]]) {
            // You can get the error like this:
            //tV.text = ((SOAPFault *)bodyPart).simpleFaultString;
            continue;
        }
        
        if([bodyPart isKindOfClass:[AvailBids_GetLocationsResponse class]]) {
            AvailBids_GetLocationsResponse *body = (AvailBids_GetLocationsResponse*) bodyPart;
            // Now you can extract the color from the response
            
            NSMutableString *s= [[NSMutableString alloc]initWithString:body.GetLocationsResult];
            NSData *data=[s dataUsingEncoding:NSUTF16StringEncoding];
            
            parser= [[NSXMLParser alloc] initWithData:data];
            
            [parser setDelegate:self];
            [parser setShouldResolveExternalEntities:NO];
            [parser parse];
            break;
        }
    }
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    
    element = elementName;
    
    if ([element isEqualToString:@"Item"]) {
        locationName   = [[NSMutableString alloc] init];
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([element isEqualToString:@"Item"]) {
        [locationName appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"Item"]) {
        [locations addObject:locationName];
    }
}




- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [locations count];
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [locations objectAtIndex:row];
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    if(row != 0){
        selectedLocation.text = [locations objectAtIndex:row];
    }
    else{
        selectedLocation.text = @"";
    }
    
}

/*
 -(void) didMoveToParentViewController:(UIViewController *)parent{
 if (![parent isEqual:self.parentViewController]) {
 NSLog(@"Back pressed");
 }
 
 NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
 NSString *documentsDirectory = [paths objectAtIndex:0];
 NSString *docPath = [documentsDirectory stringByAppendingPathComponent:@"Filters.plist"];
 
 
 
 
 NSMutableDictionary* updateVal=[[NSMutableDictionary alloc] initWithContentsOfFile:docPath];
 
 
 NSString *updateValString= [updateVal valueForKey:@"Filters"];
 
 
 
 
 
 NSMutableDictionary *filtersDict = [[NSMutableDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Filters" ofType:@"plist"]];
 NSMutableArray *filters = [filtersDict objectForKey:@"Filters"];
 NSMutableDictionary *keywords= [filters objectAtIndex:1];
 
 
 [keywords setValue:self.selectedCategory.text forKey:@"Values"];
 
 
 [filters setObject:keywords atIndexedSubscript:0];
 [filtersDict setObject:filters forKey:@"Filters"];
 
 
 [updateVal setObject:filtersDict forKey:@"Filters"];
 [updateVal writeToFile:docPath atomically:NO];
 [updateVal release];
 
 }*/


@end
