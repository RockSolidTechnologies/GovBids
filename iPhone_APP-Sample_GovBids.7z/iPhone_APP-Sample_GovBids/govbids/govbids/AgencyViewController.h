//
//  AgencyViewController.h
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AvailBids.h"

@interface AgencyViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,AvailBidsSoapResponseDelegate,NSXMLParserDelegate>
{
}
@property (strong, nonatomic) IBOutlet UITextField *selectedAgency;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerView;
@end
