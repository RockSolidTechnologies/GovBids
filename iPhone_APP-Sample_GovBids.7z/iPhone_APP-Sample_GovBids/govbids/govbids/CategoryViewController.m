//
//  CategoryViewController.m
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import "CategoryViewController.h"
#import "Categories.h"
@interface CategoryViewController ()
{
    NSXMLParser *parser;
    NSString *category;
    NSMutableArray *categories;
    NSMutableString *categoryName;
    NSString *element;
}
@end



@implementation CategoryViewController
@synthesize selectedCategory;
@synthesize pickerView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
        self.title = NSLocalizedString(@"Categoría", @"Categoría");

    }
    return self;
}


-(void) dealloc{
    [selectedCategory release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    categories= [[NSMutableArray alloc]initWithObjects:@"--Escoger Categoría--",@"Alimentos",@"Bienes",@"Concesiones",@"Construcción",@"Educación",@"Servicios",@"Ventas",nil];
    //[self loadCategories]; This will populate the categories from the GetCategories call. 
}

-(id) initController:(NSString *)name{
    self = [super init];
    
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) loadCategories{
    AvailBidsSoap *availBids= [[AvailBids AvailBidsSoap]retain];
    availBids.logXMLInOut = YES;
    
    AvailBids_GetCategories *getCategoriesRequest = [[AvailBids_GetCategories new]autorelease];
    [availBids GetCategoriesAsyncUsingParameters:getCategoriesRequest delegate:self];
}

-(void) operation:(AvailBidsSoapResponse *)operation completedWithResponse:(AvailBidsSoapResponse *)response{
    
    NSArray *responseHeaders = response.headers;
    NSArray *responseBodyParts= response.bodyParts;
    
    for(id header in responseHeaders){
        
    }
    for(id bodyPart in responseBodyParts){
        /****
         * SOAP Fault Error
         ****/
        if ([bodyPart isKindOfClass:[SOAPFault class]]) {
            // You can get the error like this:
            //tV.text = ((SOAPFault *)bodyPart).simpleFaultString;
            continue;
        }
        
        if([bodyPart isKindOfClass:[AvailBids_GetCategoriesResponse class]]) {
            AvailBids_GetCategoriesResponse *body = (AvailBids_GetCategoriesResponse*) bodyPart;
            // Now you can extract the color from the response
            
            NSMutableString *s= [[NSMutableString alloc]initWithString:body.GetCategoriesResult];
            NSData *data=[s dataUsingEncoding:NSUTF16StringEncoding];
            
            parser= [[NSXMLParser alloc] initWithData:data];
            
            [parser setDelegate:self];
            [parser setShouldResolveExternalEntities:NO];
            [parser parse];
            break;
        }
    }
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    
    element = elementName;
    
    if ([element isEqualToString:@"Item"]) {
        categoryName   = [[NSMutableString alloc] init];
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([element isEqualToString:@"Item"]) {
        [categoryName appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"Item"]) {
        [categories addObject:categoryName];
    }
}




- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [categories count];
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [categories objectAtIndex:row];
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    if(row != 0){
        selectedCategory.text = [categories objectAtIndex:row];
    }
    else{
        selectedCategory.text = @"";
    }

}

/*
-(void) didMoveToParentViewController:(UIViewController *)parent{
    if (![parent isEqual:self.parentViewController]) {
        NSLog(@"Back pressed");
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *docPath = [documentsDirectory stringByAppendingPathComponent:@"Filters.plist"];
    
    
   
    
    NSMutableDictionary* updateVal=[[NSMutableDictionary alloc] initWithContentsOfFile:docPath];
    
    
    NSString *updateValString= [updateVal valueForKey:@"Filters"];
    

    
    
    
    NSMutableDictionary *filtersDict = [[NSMutableDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Filters" ofType:@"plist"]];
    NSMutableArray *filters = [filtersDict objectForKey:@"Filters"];
    NSMutableDictionary *keywords= [filters objectAtIndex:1];

    
    [keywords setValue:self.selectedCategory.text forKey:@"Values"];
    
    
    [filters setObject:keywords atIndexedSubscript:0];
    [filtersDict setObject:filters forKey:@"Filters"];
    
    
    [updateVal setObject:filtersDict forKey:@"Filters"];
    [updateVal writeToFile:docPath atomically:NO];
    [updateVal release];
    
}*/


@end
