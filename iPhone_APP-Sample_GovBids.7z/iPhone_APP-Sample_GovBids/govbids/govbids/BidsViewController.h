//
//  RSTFirstViewController.h
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AvailBids.h"


@interface BidsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource, AvailBidsSoapResponseDelegate,NSXMLParserDelegate>
{
    
}
@property (strong,nonatomic) IBOutlet UITableView *bidsTableView;
-(void) refreshBids;
@end
