//
//  RSTFirstViewController.m
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import "BidsViewController.h"
#import "Data.h"
#import "BidDetailViewController.h"
#import "Agencies.h"

@interface BidsViewController ()
{
    NSXMLParser *parser;
    NSMutableArray *bids;
    NSMutableDictionary *Bid;
    NSMutableString *Title;
    NSMutableString *ItemID;
    NSString *element;
}
@end

@implementation BidsViewController
@synthesize bidsTableView;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Subastas", @"Subastas");
        self.tabBarItem.image = [UIImage imageNamed:@"collection"];

    }
    return self;
}

							
- (void)viewDidLoad
{
    [super viewDidLoad];

    //self.navigationItem.rightBarButtonItem= [[UIBarButtonItem alloc]initWithTitle:@"Refresh" style:UIBarButtonItemStyleBordered target:self action:@selector(refreshBids)];
    //[[Data sharedData]loadBids];
    bids= [[NSMutableArray alloc]init];
    [self loadBids];
    
    
	// Do any additional setup after loading the view, typically from a nib.
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) loadBids{
    AvailBidsSoap *availBids= [[AvailBids AvailBidsSoap]retain];
    availBids.logXMLInOut = NO;
    
    AvailBids_GetBids *getBidsRequest = [[AvailBids_GetBids new]autorelease];
    getBidsRequest.agency=@"";
    getBidsRequest.category=@"";
    getBidsRequest.location=@"";
    getBidsRequest.title=@"";
    
    [availBids GetBidsAsyncUsingParameters:getBidsRequest delegate:self];
    
    
}

-(void) refreshBids{

    bids=nil;    
    bids= [[NSMutableArray alloc]init];
    [self loadBids];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return bids.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"] autorelease];
    }

    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [[bids objectAtIndex:indexPath.row] objectForKey:@"Title"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    NSString *itemID= [[bids objectAtIndex:indexPath.row] objectForKey:@"ItemID"];
    
    NSString *url= [NSString stringWithFormat:@"http://www2.pr.gov/subasta/Pages/aviso.aspx?itemID=%@",itemID];
    
    [self.navigationController pushViewController:[[BidDetailViewController alloc] initWithURL:url] animated:YES];
    
}


- (void)dealloc {
    [bidsTableView release];
    [super dealloc];
}

-(void) operation:(AvailBidsSoapOperation *)operation completedWithResponse:(AvailBidsSoapResponse *)response{
    
    NSArray *responseHeaders = response.headers;
    NSArray *responseBodyParts= response.bodyParts;
    
    for(id header in responseHeaders){
        
    }
    for(id bodyPart in responseBodyParts){
        /****
         * SOAP Fault Error
         ****/
        if ([bodyPart isKindOfClass:[SOAPFault class]]) {
            // You can get the error like this:
            //tV.text = ((SOAPFault *)bodyPart).simpleFaultString;
            continue;
        }
        
        if([bodyPart isKindOfClass:[AvailBids_GetBidsResponse class]]) {
            AvailBids_GetBidsResponse *body = (AvailBids_GetBidsResponse*) bodyPart;
            // Now you can extract the color from the response
            
            NSMutableString *s= [[NSMutableString alloc]initWithString:body.GetBidsResult];
            NSData *data=[s dataUsingEncoding:NSUTF16StringEncoding];
            
            parser= [[NSXMLParser alloc] initWithData:data];
            
            [parser setDelegate:self];
            [parser setShouldResolveExternalEntities:NO];
            [parser parse];
            break;
        }
        
    }
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    element = elementName;
    
    if ([element isEqualToString:@"Bid"]) {
        
        Bid    = [[NSMutableDictionary alloc] init];
        Title   = [[NSMutableString alloc] init];
        ItemID    = [[NSMutableString alloc] init];
        
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([element isEqualToString:@"Title"]) {
        [Title appendString:string];
    } else if ([element isEqualToString:@"ItemID"]) {
        [ItemID appendString:string];
    }
    
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.bidsTableView setEditing:editing animated:animated];
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"Bid"]) {
        
        [Bid setObject:Title forKey:@"Title"];
        [Bid setObject:ItemID forKey:@"ItemID"];
        
        [bids addObject:[Bid copy]];
    }
    
}
- (void)parserDidEndDocument:(NSXMLParser *)parser {
    [bidsTableView reloadData];    
}
@end
