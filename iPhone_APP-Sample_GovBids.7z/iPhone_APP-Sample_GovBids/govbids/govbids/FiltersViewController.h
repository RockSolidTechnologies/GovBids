//
//  FiltersViewController.h
//  GovBids
//
//  Created by RSTDeveloper01 on 6/2/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FiltersViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,retain) IBOutlet UITableView *filtersView;

@end
