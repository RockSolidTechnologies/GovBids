//
//  RSTSecondViewController.h
//  GovBids
//
//  Created by RSTDeveloper01 on 5/31/13.
//  Copyright (c) 2013 com.rstgov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BidDetailViewController : UIViewController<UIWebViewDelegate>{
    NSString *url;
}
@property   (nonatomic,retain) IBOutlet UIWebView *webView;
@property   (nonatomic,strong) NSString *url;

-(id)initWithURL:(NSString *)url;

@end
