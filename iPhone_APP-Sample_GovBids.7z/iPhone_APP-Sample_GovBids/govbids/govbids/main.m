//
//  main.m
//  govbids
//
//  Created by RSTDeveloper01 on 6/5/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RSTAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RSTAppDelegate class]));
    }
}
