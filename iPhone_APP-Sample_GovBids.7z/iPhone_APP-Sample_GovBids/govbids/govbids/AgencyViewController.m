//
//  AgencyViewController.m
//  govbids
//
//  Created by RSTDeveloper01 on 6/6/13.
//  Copyright (c) 2013 com.rst. All rights reserved.
//

#import "AgencyViewController.h"
@interface AgencyViewController ()
{
    NSXMLParser *parser;
    NSString *agency;
    NSMutableArray *agencies;
    NSMutableString *agencyName;
    NSString *element;
}
@end



@implementation AgencyViewController
@synthesize selectedAgency;
@synthesize pickerView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
        self.title = NSLocalizedString(@"Agencia", @"Agencia");
        
    }
    return self;
}

-(id) initController:(NSString *)name{
    self = [super init];
    return self;
}

-(void) dealloc{
    [selectedAgency release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    agencies= [[NSMutableArray alloc]initWithObjects:@"--Escoger Agencia--",@"Administración de Servicios de Salud Mental y Contra la Adicción (Dpto. Salud)",@"Administración para el Desarrollo de Empresas Agropecuarias (Dpto. Agricultura",@"Autoridad de Acueductos y Alcantarillados (AAA)",@"Autoridad para el Financiamiento de la Infraestructura de Puerto Rico (AFI)",@"Corporación del Fondo del Seguro del Estado (CFSE)",@"Corporación del Proyecto ENLACE del Caño Martín Peña",@"Departamento de Educación (DE)",@"Departamento de Justicia (DJ)",@"Departamento de Recreación y Deportes (DRD)",@"Departamento de Recursos Naturales y Ambientales (DRNA)",@"Departamento de Salud (DS)",@"Departamento de Transportación y Obras Públicas (DTOP)",@"Junta de Gobierno del Servicio 9-1-1",@"Policía de Puerto Rico",@"Universidad de Puerto Rico", nil];
       //[self loadAgencies]; Needs to be implemented to populate the picker view
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark Load Agencies 
-(void) loadAgencies{
    AvailBidsSoap *availBids= [[AvailBids AvailBidsSoap]retain];
    availBids.logXMLInOut = YES;
    
    AvailBids_GetAgencies *getAgenciesRequest = [[AvailBids_GetAgencies new]autorelease];
    [availBids GetAgenciesAsyncUsingParameters:getAgenciesRequest delegate:self];
}

-(void) operation:(AvailBidsSoapResponse *)operation completedWithResponse:(AvailBidsSoapResponse *)response{
    
    NSArray *responseHeaders = response.headers;
    NSArray *responseBodyParts= response.bodyParts;
    
    for(id header in responseHeaders){
        
    }
    for(id bodyPart in responseBodyParts){
        /****
         * SOAP Fault Error
         ****/
        if ([bodyPart isKindOfClass:[SOAPFault class]]) {
            // You can get the error like this:
            //tV.text = ((SOAPFault *)bodyPart).simpleFaultString;
            continue;
        }
        
        if([bodyPart isKindOfClass:[AvailBids_GetAgenciesResponse class]]) {
            AvailBids_GetAgenciesResponse *body = (AvailBids_GetAgenciesResponse*) bodyPart;
            // Now you can extract the color from the response
            
            NSMutableString *s= [[NSMutableString alloc]initWithString:body.GetAgenciesResult];
            NSData *data=[s dataUsingEncoding:NSUTF16StringEncoding];
            
            parser= [[NSXMLParser alloc] initWithData:data];
            
            [parser setDelegate:self];
            [parser setShouldResolveExternalEntities:NO];
            [parser parse];
            break;
        }
    }
}

#pragma mark Parser methods

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    
    element = elementName;
    
    if ([element isEqualToString:@"Item"]) {
        agencyName   = [[NSMutableString alloc] init];
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([element isEqualToString:@"Item"]) {
        [agencyName appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"Item"]) {
        [agencies addObject:agencyName];
    }
}




- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [agencies count];
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [agencies objectAtIndex:row];
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    if(row != 0){
        selectedAgency.text = [agencies objectAtIndex:row];
    }
    else{
        selectedAgency.text = @"";
    }
    
}


/* Update the value selected value at the picklist
 
 -(void) didMoveToParentViewController:(UIViewController *)parent{
 if (![parent isEqual:self.parentViewController]) {
 NSLog(@"Back pressed");
 }
 
 NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
 NSString *documentsDirectory = [paths objectAtIndex:0];
 NSString *docPath = [documentsDirectory stringByAppendingPathComponent:@"Filters.plist"];
 
 
 
 
 NSMutableDictionary* updateVal=[[NSMutableDictionary alloc] initWithContentsOfFile:docPath];
 
 
 NSString *updateValString= [updateVal valueForKey:@"Filters"];
 
 
 
 
 
 NSMutableDictionary *filtersDict = [[NSMutableDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Filters" ofType:@"plist"]];
 NSMutableArray *filters = [filtersDict objectForKey:@"Filters"];
 NSMutableDictionary *keywords= [filters objectAtIndex:1];
 
 
 [keywords setValue:self.selectedCategory.text forKey:@"Values"];
 
 
 [filters setObject:keywords atIndexedSubscript:0];
 [filtersDict setObject:filters forKey:@"Filters"];
 
 
 [updateVal setObject:filtersDict forKey:@"Filters"];
 [updateVal writeToFile:docPath atomically:NO];
 [updateVal release];
 
 }*/


@end
